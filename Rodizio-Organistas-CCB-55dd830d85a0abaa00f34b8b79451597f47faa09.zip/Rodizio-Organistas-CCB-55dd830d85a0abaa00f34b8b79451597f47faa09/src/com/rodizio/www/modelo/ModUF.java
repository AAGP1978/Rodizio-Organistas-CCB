package com.rodizio.www.modelo;

public class ModUF {
	private String id_Estado;
	private String nome_Estado;
	private String uf_Estado;
	public String getId_Estado() {
		return id_Estado;
	}
	public void setId_Estado(String id_Estado) {
		this.id_Estado = id_Estado;
	}
	public String getNome_Estado() {
		return nome_Estado;
	}
	public void setNome_Estado(String nome_Estado) {
		this.nome_Estado = nome_Estado;
	}
	public String getUf_Estado() {
		return uf_Estado;
	}
	public void setUf_Estado(String uf_Estado) {
		this.uf_Estado = uf_Estado;
	}
	

}
