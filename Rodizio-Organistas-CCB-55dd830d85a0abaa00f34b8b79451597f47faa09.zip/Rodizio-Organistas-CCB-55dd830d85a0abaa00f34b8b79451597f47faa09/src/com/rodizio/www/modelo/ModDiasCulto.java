package com.rodizio.www.modelo;

public class ModDiasCulto {
	private String diaCulto;
	private String idIgreja;
	private int statusDiaCulto;
	
	public String getIdIgreja() {
		return idIgreja;
	}
	public void setIdIgreja(String idIgreja) {
		this.idIgreja = idIgreja;
	}
	public String getDiaCulto() {
		return diaCulto;
	}
	public void setDiaCulto(String diaCulto) {
		this.diaCulto = diaCulto;
	}
	public int getStatusDiaCulto() {
		return statusDiaCulto;
	}
	public void setStatusDiaCulto(int statusDiaCulto) {
		this.statusDiaCulto = statusDiaCulto;
	}
	
	

}
