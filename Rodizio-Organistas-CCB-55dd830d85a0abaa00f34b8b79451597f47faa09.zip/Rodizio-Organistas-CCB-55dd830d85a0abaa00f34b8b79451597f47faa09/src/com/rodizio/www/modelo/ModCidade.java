package com.rodizio.www.modelo;

public class ModCidade {
	
	private String idCidade;
	private String codEstado;
	private String nome_Cidade;
	
	public String getIdCidade() {
		return idCidade;
	}
	public void setIdCidade(String idCidade) {
		this.idCidade = idCidade;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getNome_Cidade() {
		return nome_Cidade;
	}
	public void setNome_Cidade(String nome_Cidade) {
		this.nome_Cidade = nome_Cidade;
	}

}
