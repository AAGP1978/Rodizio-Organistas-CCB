package com.rodizio.www.modelo;

public class ModTipoPessoa {
	private String id_tipo_pessoa;
	private String tipo_pessoa;
	
	public String getId_tipo_pessoa() {
		return id_tipo_pessoa;
	}
	public void setId_tipo_pessoa(String id_tipo_pessoa) {
		this.id_tipo_pessoa = id_tipo_pessoa;
	}
	public String getTipo_pessoa() {
		return tipo_pessoa;
	}
	public void setTipo_pessoa(String tipo_pessoa) {
		this.tipo_pessoa = tipo_pessoa;
	}
	

}
